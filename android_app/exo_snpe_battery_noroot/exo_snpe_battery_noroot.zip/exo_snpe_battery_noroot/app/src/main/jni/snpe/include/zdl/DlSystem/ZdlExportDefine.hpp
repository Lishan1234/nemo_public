//=============================================================================
//
//  Copyright (c) 2015 Qualcomm Technologies, Inc.
//  All Rights Reserved.
//  Confidential and Proprietary - Qualcomm Technologies, Inc.
//
//=============================================================================

#ifndef _ZDL_EXPORT_DEFINE_HPP_
#define _ZDL_EXPORT_DEFINE_HPP_

#ifndef ZDL_EXPORT
#define ZDL_EXPORT __attribute__((visibility("default")))
#endif

#endif
