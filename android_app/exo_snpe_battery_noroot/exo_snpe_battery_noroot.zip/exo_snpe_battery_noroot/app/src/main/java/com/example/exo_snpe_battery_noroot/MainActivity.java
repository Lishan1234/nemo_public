package com.example.exo_snpe_battery_noroot;

import androidx.appcompat.app.AppCompatActivity;

import android.os.BatteryManager;
import android.os.Bundle;
import android.view.WindowManager;

import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout;
import com.google.android.exoplayer2.ui.PlayerView;

public class MainActivity extends AppCompatActivity {


    public native long jniFunction(int minutes, String dlc, String input, String output, String log, boolean doLog);

    static{
        System.loadLibrary("snpeJNI");
    }


    PlayerView mPlayerView;
    SimpleExoPlayer mSimpleExoPlayer;
    BatteryManager mBatteryManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


        prepareExoPlayer();

    }

    private void prepareExoPlayer(){
        mPlayerView = findViewById(R.id.video_view);
        DefaultRenderersFactory renderFactory = new DefaultRenderersFactory(this);
        renderFactory.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER);
        mSimpleExoPlayer = new SimpleExoPlayer.Builder(this, renderFactory).build();
        mSimpleExoPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
        mPlayerView.setPlayer(mSimpleExoPlayer);
        mPlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT);
        mSimpleExoPlayer.prepare(createMediaSource());
    }
}
